Redstone Paste Mod v1.5.1 - By FyberOptic (fyberoptic@gmail.com)
------------------------------------------------------------------------------

This mod adds a paste form of redstone, which will stick to a variety of 
surfaces, including walls and ceilings.  Also included are sticky repeaters
and sticky comparators.

Placement of redstone paste is different than that of redstone dust; you can
place it in each of the four directions of a block face.  This allows you to 
create very tight pathways, and avoid transmitting redstone signals to blocks 
you don't specifically intend.  You can also remove individual paste segments
as desired, including all of them on a face at once by clicking in the center.

Holding the sneak key allows you to place multiple paste segments at once, 
placing both the segment you've selected as well as the one opposite.  If 
sneaking when placing paste in the center area, it will place paste in all 
four directions of a face.

You can hide paste, sticky repeaters, and sticky comparators using half-slabs 
by right-clicking them while holding one.  Note that this is only possible 
when a single face within a block space contains a Redstone Paste object.  A
ghost image of the slab will appear when it's possible to cover it.  To remove 
it, simply break with any tool.

The paste is a shapeless recipe of a slimeball with a piece of redstone dust,
yielding four paste.  This can be changed in the config file, both to
change the number of paste per recipe, or to use the alternate recipe of
a slimeball surrounded by redstone dust.

You can also craft sticky repeaters, to strengthen your redstone currents
on walls and ceilings as well.  They're functionally equivalent, with the 
same delay settings.  The crafting recipe is shapeless, using a normal 
redstone repeater and a slimeball.  Sticky comparators are also functionally
identical to redstone comparators, and follow a similar recipe as above, using 
a regular redstone comparator and a slimeball.

This mod was built using Forge #804 for Minecraft 1.6.2, and is compatible
with Minecraft 1.6.4.


-- Changelog --
v1.5.1 - November 11th, 2013
 - Individual faces of paste now have their own current values
 - Highlighter now draws comparator outline
 - Various code optimizations and clean-up

v1.5 - November 1st, 2013
 - Added sticky comparators
 - Changed sticky repeater textures and icon

v1.4.3 - October 30th, 2013
 - Fixed not being able to set sticky repeater delay if hand is empty
 - Fixed current propagation bug affecting comparators 
 - Made sticky repeaters lockable by vanilla repeaters

v1.4.2 - October 28th, 2013
 - Fixed crash bug in highlighter related to Railcraft's hidden block  
 - Breaking sticky repeaters now triggers redstone propagation
 - Optimized rendering slightly of sticky repeater locking bar and paste highlighter    
 
v1.4.1 - October 27th, 2013
 - Added locking functionality to sticky repeaters (because I forgot it!)
 - Minor change to redstone current propagation: paste must now be directly connected to redstone sources (levers, torches, etc); also fixes a compatibility issue with redstone dust
 - Modified paste rendering, should improve z-fighting with blocks in distance, and prevent flickering when using Optifine
 - Improved lighting synchronization of sticky repeaters, helps with issue on servers 
 - Fixed bug with redstone propagation and sticky repeaters causing a current feedback loop
 - Fixed bug with placing paste where certain hidden blocks are present (such as with Railcraft)
 - Added workaround for crash caused by Optifine when highlighter is rendering a ghost slab

v1.4 - October 25th, 2013
 - Added sticky repeaters, craftable with a repeater and a slimeball, and practically 100% functionally equivalent
 - Changed paste color transition code, allowing you to set off/middle/on colors in the config
 - Made paste respond better to indirect power (for repeater compatibility)
 - Fixed creative mode bug where shift-click placement of paste still checked for sufficient items in stack
 - Slab cover no longer drops when paste beneath is removed
 - Changed half-slab fail-safe code; instead of removing slab, now displays stone if slab came from a mod that was uninstalled
 - Tweaked rendering to avoid z-fighting at paste segment axis
 - Ray-tracing optimizations

v1.3 - October 17th, 2013
 - Added ability to click on a paste face with a half-slab to cover it  
 - Added config options to set paste recipe type and amount
 - Fixed paste being completely destroyed by water (now obstructs it)
 - Fixed bug preventing you from placing blocks adjacent to paste when clicking a paste face (broken by 1.2)
 - Fixed not being able to place paste on solid sides of some non-standard blocks
 - Changed highlighter color fading technique (possibly fixes weirdness when using shaders)

v1.2 - October 9th, 2013
 - Overhauled highlighter and paste placement, now encompasses entire block face  
 - Added sneak key modifier: sneaking while placing or removing paste affects the opposite segment as well, or places all four segments if done in the center
 - Fixed raytracing issue when sneaking
 - Stopped paste from dropping items when breaking in creative mode
 - Fixed color of particles when breaking paste segments
 - Fixed paste breaking sound/particles not occurring in survival mode
 - Fixed highlighter timing
 
v1.1.2 - October 3rd, 2013
 - Fixed issues related to redstone propagation around corners
 - Made solid blocks obstruct redstone around corners
 - Fixed visual glitch with highlighter
 
v1.1.1 - September 24th, 2013
 - Fixed server compatibility
 - Fixed highlighter appearing when hand is empty
 
v1.1 - September 23rd, 2013
 - Added paste segment highlighter, to see where paste will be placed on a block face
 - Added ability to remove individual paste segments
 - Refined paste segment hitbox area
 - Fixed issue of distance required from block to place paste
 - Fixed creative mode from breaking all segments in block space
 - Fixed propagation strength between paste and dust
 - Improved paste colors and color transition

v1.0 - September 20th, 2013 
 - Initial release!


-- License -- 
Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License
http://creativecommons.org/licenses/by-nc-nd/3.0/

